package com.demo.att.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.demo.att.model.Cart;
import com.demo.att.model.Device;
import com.demo.att.service.CartService;
import com.demo.att.service.DeviceService;
import com.demo.util.Constants;

@RestController
public class CartController {

	@Autowired
	private CartService cartService;
	
	public void setCartService(CartService cartService) {
		this.cartService = cartService;
	}

	@Autowired
	DeviceService deviceService;
	
	@RequestMapping(value = "/shop/wireless/devices/cart/addDevice", method = RequestMethod.POST)
	public ResponseEntity<Void> addCart(@ModelAttribute Cart cart) throws IOException{
		cartService.addCart(cart);
		//HttpHeaders headers = new HttpHeaders();
		//headers.setLocation(ucb.path("/device/{id}").buildAndExpand(cart.getCartId()).toUri());
		return new ResponseEntity<Void>(HttpStatus.CREATED);
	}

	@RequestMapping(value = "/shop/wireless/devices/cart/add", method = RequestMethod.GET)
	public List<Device> addDeviceToCart(HttpServletRequest request) {
		String deviceId = request.getParameter("deviceId");
		List<Device> deviceList = addDevicesToSession(request, deviceId);
		return deviceList;
	}

	@SuppressWarnings("unchecked")
	private List<Device> addDevicesToSession(HttpServletRequest request,
			String deviceId) {
		List<Device> devicesList = new ArrayList<Device>();
		boolean isProductAdded = false;
		devicesList = (List<Device>) request.getSession().getAttribute(
				Constants.SESSION_DEVICE_ATTR);
		if (StringUtils.isEmpty(devicesList)) {
			setDevicesInSession(request, deviceId);
		} else {
			for (Device device : devicesList) {
				String deviceIdAdded = device.getDeviceId();
				if (!StringUtils.isEmpty(deviceIdAdded)
						&& deviceIdAdded.equalsIgnoreCase(deviceId)) {
					isProductAdded = true;
				}
			}

			if (!isProductAdded) {
				setDevicesInSession(request, deviceId);
			} else {
				incrementQuantityInSession(request, deviceId);
			}

		}
		devicesList = (List<Device>) request.getSession().getAttribute(
				Constants.SESSION_DEVICE_ATTR);
		return devicesList;
	}

	@SuppressWarnings("unchecked")
	private List<Device> getDevicesFromSession(HttpServletRequest request) {
		List<Device> devicesList = new ArrayList<Device>();
		devicesList = (List<Device>) request.getSession().getAttribute(
				Constants.SESSION_DEVICE_ATTR);
		return devicesList;
	}

	@SuppressWarnings("unchecked")
	private void setDevicesInSession(HttpServletRequest request, String deviceId) {
		List<Device> devicesList = new ArrayList<Device>();
		devicesList = (List<Device>) request.getSession().getAttribute(
				Constants.SESSION_DEVICE_ATTR);
		Device device = deviceService.getDeviceDetails(deviceId);
		if (StringUtils.isEmpty(devicesList)) {
			devicesList = new ArrayList<Device>();
		}
		devicesList.add(device);

		request.getSession().setAttribute(Constants.SESSION_DEVICE_ATTR,
				devicesList);
	}

	@SuppressWarnings("unchecked")
	private void incrementQuantityInSession(HttpServletRequest request,
			String deviceId) {
		List<Device> devicesList = new ArrayList<Device>();
		devicesList = (List<Device>) request.getSession().getAttribute(
				Constants.SESSION_DEVICE_ATTR);

		for (Device device : devicesList) {
			String deviceIdAdded = device.getDeviceId();
			if (!StringUtils.isEmpty(deviceIdAdded)
					&& deviceIdAdded.equalsIgnoreCase(deviceId)) {
				int quantity = device.getQuantity() + 1;
				double price = device.getPrice() * quantity;
				device.setQuantity(quantity);
				device.setPrice(price);
			}
		}
		request.getSession().setAttribute(Constants.SESSION_DEVICE_ATTR,
				devicesList);
	}

	@RequestMapping(value = "/shop/wireless/devices/cart/view", method = RequestMethod.GET)
	public List<Device> viewCart(HttpServletRequest request) {
		List<Device> deviceList = getDevicesFromSession(request);
		return deviceList;
	}
}
