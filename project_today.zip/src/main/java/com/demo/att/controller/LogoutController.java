package com.demo.att.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.demo.att.model.User;
import com.demo.att.service.LoginService;

@RestController("logoutController")
@RequestMapping("/")
public class LogoutController {

	@Autowired
	LoginService loginService;

	@RequestMapping(value = "/logout", method = RequestMethod.POST)
	public void logout(HttpServletRequest request, HttpServletResponse response) {
		deleteUserInSession(request);
	}

	private void deleteUserInSession(HttpServletRequest request) {
		request.getSession().setAttribute("user", new User());
	}
}
