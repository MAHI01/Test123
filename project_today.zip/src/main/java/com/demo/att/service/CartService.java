package com.demo.att.service;

import java.util.List;

import com.demo.att.model.Cart;
import com.demo.att.model.Device;

public interface CartService {
	public void addCart(Cart cart);
	public List<Cart> listProducts();
	boolean isDeviceExit(Device device);
}
