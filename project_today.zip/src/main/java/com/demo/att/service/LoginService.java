package com.demo.att.service;

import com.demo.att.model.Login;
import com.demo.att.model.User;

public interface LoginService {
	public User getUserProfile(Login login);

}
