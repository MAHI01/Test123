package com.demo.att.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.att.dao.CartDao;
import com.demo.att.model.Cart;
import com.demo.att.model.Device;
import com.demo.att.service.CartService;

@Service("cartService")
public class CartServiceImpl implements CartService {

	@Autowired
	CartDao cartDao;
	
	public void setCartDao(CartDao cartDao) {
		this.cartDao = cartDao;
	}

	@Override
	public void addCart(Cart cart) {
		cartDao.addCart(cart);
	}

	@Override
	public List<Cart> listProducts() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isDeviceExit(Device device) {
		// TODO Auto-generated method stub
		return false;
	}


	

}
