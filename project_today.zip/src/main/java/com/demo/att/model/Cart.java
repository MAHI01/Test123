package com.demo.att.model;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

public class Cart {

	@Id
	@GeneratedValue
	@Column
	private String cartId;
	
	@Column
	private String productName;
	
	@Column
	private double price;
	
	@Column
	private String imgSource;
	
	@Column
	private int quantity;

	public String getCartId() {
		return cartId;
	}

	public void setCartId(String cartId) {
		this.cartId = cartId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getImgSource() {
		return imgSource;
	}

	public void setImgSource(String imgSource) {
		this.imgSource = imgSource;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Cart(String cartId, String productName, double price,
			String imgSource, int quantity) {
		super();
		this.cartId = cartId;
		this.productName = productName;
		this.price = price;
		this.imgSource = imgSource;
		this.quantity = quantity;
	}
	
	public Cart(){
		
	}

	@Override
	public String toString() {
		return "Cart [cartId=" + cartId + ", productName=" + productName
				+ ", price=" + price + ", imgSource=" + imgSource
				+ ", quantity=" + quantity + "]";
	}
	
}
