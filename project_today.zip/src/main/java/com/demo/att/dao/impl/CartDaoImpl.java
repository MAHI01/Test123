package com.demo.att.dao.impl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.demo.att.dao.CartDao;
import com.demo.att.model.Cart;
import com.demo.att.model.Device;

@Repository("cartDao")
public class CartDaoImpl implements CartDao {
	
	//private static final Logger logger = LoggerFactory.getLogger(CartDaoImpl.class);
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public void addCart(Cart cart) {
		org.hibernate.Session session = this.sessionFactory.getCurrentSession();
		Transaction transaction = session.beginTransaction();
		if(cart != null){
			try {
				session.save(cart);
				transaction.commit();
			} catch (Exception e) {
				transaction.rollback();
				session.close();
			}
		}
	}

	@Override
	public List<Cart> listProducts() {
		// TODO Auto-generated method stub
		return null;
	}
	/*public boolean isDeviceExit(Device device){
		
		return
	}*/

	@Override
	public boolean isDeviceExit(Device device) {
		return false;
		
	}

}
