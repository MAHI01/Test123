package com.demo.att.dao;

import com.demo.att.model.Login;
import com.demo.att.model.User;

public interface LoginDao {
	public User getUserProfile(Login login);
}
