(function() {
	angular.module('Ecommerce').controller('LoginController', LoginController);

	LoginController.$inject = [ '$state', 'getUrlRequest', '$http', '$window',
			'$rootScope' ];

	function LoginController($state, getUrlRequest, $http, $window, $rootScope) {
		var vm = this;
		vm.showLoaderIndicator = true;
		vm.showHeader = false;
		vm.invalidLogin = false;
		
		$rootScope.$emit("HideHeader", {});
		
		vm.login = function(userName, password) {
			var method = 'POST';
			var url = './login';
			var params = {
				"username" : vm.username,
				'password' : vm.password
			};
			getUrlRequest.makeHttpCall(url, method, params).then(
					function(resp) {
						vm.response = resp.data;
						if (vm.response.userName != null) {
							$window.sessionStorage.setItem("loginUser",
									vm.response.emailId);
							$rootScope.$emit("SetUserInHeader", {});
							$state.go('home', {}, {
								reload : true
							});
						} else {
							vm.invalidLogin = true;
						}
					});
		};

	}
	;
})();