(function() {
	angular.module('Ecommerce').controller('LogoutController', LogoutController);

	LogoutController.$inject = ['$window','$state'];

	function LogoutController($window,$state) {
		var vm = this;
		vm.showHeader = true;
		vm.showLoaderIndicator = true;
		vm.invalidLogin = false;		
		//Session.clear();
		$window.sessionStorage.removeItem("loginUser");
		$state.go('login', {reload: true});

	}
	;
})();