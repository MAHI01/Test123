(function() {
	angular.module('Ecommerce')
			.controller('HeaderController', HeaderController);

	HeaderController.$inject = [ '$window', '$location', '$state',
			'getUrlRequest', '$scope', '$rootScope' ];

	function HeaderController($window, $location, $state, getUrlRequest, scope,
			$rootScope) {
		var vm = this;
		vm.isLoggedIn = false;
		vm.loginUser = null;
		vm.showHeader = true;
		vm.logout = function() {
			var method = 'POST';
			var url = './logout';
			var params = {};
			getUrlRequest.makeHttpCall(url, method, params).then(
					function(resp) {
						vm.isLoggedIn = false;
						vm.loginUser = null;
						$window.sessionStorage.removeItem("loginUser");
						$state.go('home', {}, {
							reload : true
						});
					});
		};

		$rootScope.$on("SetUserInHeader", function() {
			vm.setUserInHeader();
		});

		vm.setUserInHeader = function() {
			vm.loginUser = $window.sessionStorage.getItem("loginUser");
			if (vm.loginUser != null) {
				vm.isLoggedIn = true;
			} else {
				vm.isLoggedIn = false;
			}
		};

		$rootScope.$on("HideHeader", function() {
			vm.showHeader = false;
		});

		$rootScope.$on("ShowHeader", function() {
			vm.showHeader = true;
		});
	}
	;
})();