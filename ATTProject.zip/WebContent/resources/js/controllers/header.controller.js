(function(){
	angular.module('Ecommerce').controller('HeaderController',HeaderController);
	
	HeaderController.$inject=['$window','$location','$state'];
	
	function HeaderController($window,$location,$state){
		var vm = this;
		vm.isLoggedIn = false;
		vm.loginUser = $window.sessionStorage.getItem("loginUser");
		if(vm.loginUser != null){
			vm.isLoggedIn = true;
		}else{
			vm.isLoggedIn = false;
		}
		
		vm.logout = function(){
			//Session.clear();
			$window.sessionStorage.removeItem("loginUser");
			$state.go('login', {}, { reload: true });
		};
	};
})();