(function(){
	angular.module('Ecommerce').controller('HomeController',HomeController);
	
	HomeController.$inject=['$window'];
	
	function HomeController($window){
		vm =this;
		vm.showHeader = true;
		//vm.loginHome = $window.sessionStorage.getItem("loginUser");
	};
})();