(function() {
	angular.module('Ecommerce').controller('WirelessController',
			WirelessController);

	WirelessController.$inject = [ '$state', 'getUrlRequest', '$http' ];

	function WirelessController($state, getUrlRequest, $http) {
		var vm = this;
		vm.showHeader = true;
		vm.showLoaderIndicator = true;
		var method = 'GET';
		var url = './shop/wireless/devices/';
		var params = {};
		getUrlRequest.makeHttpCall(url, method, params).then(function(resp) {
			vm.response = resp.data;
			vm.showLoaderIndicator = false;
		});
		vm.deviceDetails = function(deviceId) {
			$state.go('productdetail', {
				productId : deviceId
			});
		};

		vm.addToCart = function(deviceId) {
			var method = 'GET';
			var url = './shop/wireless/devices/cart/add';
			var params = {
				"deviceId" : deviceId
			};
			getUrlRequest.makeHttpCall(url, method, params).then(
					function(resp) {
						vm.response = resp.data;
						vm.showLoaderIndicator = false;
						$state.go('checkout');
					});
		};
	}
	;
})();