(function() {
	angular.module('Ecommerce').controller('WiredController', WiredController);

	WiredController.$inject = [ '$state', 'getUrlRequest', '$http'];

	function WiredController($state, getUrlRequest, $http) {
		var vm = this;
		vm.showHeader = true;
		vm.checkout=function(id){
			$state.go('checkout', {productId: id});
		};
	};
})();