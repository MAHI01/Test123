(function(){
	angular.module('Ecommerce').controller('CheckoutController',CheckoutController);
	
	CheckoutController.$inject=['$stateParams','getUrlRequest'];
	
	function CheckoutController($stateParams,getUrlRequest){
		var vm=this;
		vm.showHeader = true;
		vm.productDetails='';
		var url = "./shop/wireless/devices/cart/view";
		var method= "GET";
		var params = {};
		getUrlRequest.makeHttpCall(url, method, params).then(function(resp){
			vm.cartDetails=resp.data;
		});
	};
})();