(function() {
	angular.module('Ecommerce').controller('LoginController', LoginController);

	LoginController.$inject = [ '$state', 'getUrlRequest', '$http','$window' ];

	function LoginController($state, getUrlRequest, $http, $window) {
		var vm = this;
		vm.showLoaderIndicator = true;
		vm.showHeader = false;
		vm.invalidLogin = false;
		//$state.reload();
		//$state.go($state.current, {}, {reload: true}); 
		vm.login = function(userName, password) {
			var method = 'POST';
			var url = './login';
			var params = {
				"username" : vm.username,
				'password' : vm.password
			};
			getUrlRequest.makeHttpCall(url, method, params).then(
					function(resp) {
						vm.response = resp.data;
						if(vm.response.userName != null){
							$window.sessionStorage.setItem("loginUser", vm.response.emailId);
							//$state.go('home', {reload: true});
							$state.go('home', {}, { reload: true });
						}else{
							vm.invalidLogin = true;
						}
					});
		};

	}
	;
})();