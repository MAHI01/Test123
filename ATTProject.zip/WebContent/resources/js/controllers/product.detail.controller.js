(function(){
	angular.module('Ecommerce').controller('ProductdetailController',ProductdetailController);
	
	ProductdetailController.$inject=['$state','$stateParams','getUrlRequest'];
	
	function ProductdetailController($state, $stateParams,getUrlRequest){
		var vm=this;
		vm.productDetails='';
		var deviceId = $stateParams.productId;
		var url = "./shop/wireless/devices/details";
		var method= "GET";
		var params = {"deviceId":deviceId};
		getUrlRequest.makeHttpCall(url, method, params).then(function(resp){
			vm.productDetails=resp.data;
		});
		
		vm.addToCart = function(deviceId) {
			var method = 'GET';
			var url = './shop/wireless/devices/cart/add';
			var params = {
				"deviceId" : deviceId
			};
			getUrlRequest.makeHttpCall(url, method, params).then(
					function(resp) {
						vm.response = resp.data;
						vm.showLoaderIndicator = false;
						$state.go('checkout');
					});
		};
	};
})();