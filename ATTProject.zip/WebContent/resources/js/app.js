(function() {
	angular.module('Ecommerce', [ 'ui.router' ]).config(ConfigFunction);
	ConfigFunction.$inject = [ '$stateProvider', '$urlRouterProvider'];

	function ConfigFunction($stateProvider, $urlRouterProvider,
			$locationProvider) {
		$stateProvider.state('home', {
			url : '/home',
			controller : 'HomeController',
			controllerAs : 'vm',
			templateUrl : './resources/views/home.html'
		}).state('wired', {
			url : '/wired',
			controller : 'WiredController',
			controllerAs : 'vm',
			templateUrl : './resources/views/wired.html'
		}).state('wireless',{
			url : '/wireless',
			controller : 'WirelessController',
			controllerAs : 'vm',
			templateUrl : './resources/views/wireless.html'		
		}).state('checkout', {
			url : '/checkout',
			controller : 'CheckoutController',
			controllerAs : 'vm',
			templateUrl : './resources/views/checkout.html'
		}).state('productdetail', {
			url : '/productdetail/:productId',
			controller : 'ProductdetailController',
			controllerAs : 'vm',
			templateUrl : './resources/views/productdetail.html'
		}).state('login', {
			url : '/login',
			controller : 'LoginController',
			controllerAs : 'vm',
			templateUrl : './resources/views/login.html'
		}).state('logout', {
			url : '/logout',
			controller : 'LogoutController',
			controllerAs : 'vm',
			templateUrl : './resources/views/login.html'
		});
		$urlRouterProvider.otherwise('/home');
	};

})();