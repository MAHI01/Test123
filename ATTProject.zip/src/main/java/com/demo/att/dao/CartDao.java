package com.demo.att.dao;

import java.util.List;

import com.demo.att.model.Device;

public interface CartDao {
	public List<Device> addDevice(String deviceId);
}
