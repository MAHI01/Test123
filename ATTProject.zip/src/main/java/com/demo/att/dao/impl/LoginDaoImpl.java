package com.demo.att.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.demo.att.dao.LoginDao;
import com.demo.att.model.Login;
import com.demo.att.model.User;
import com.demo.util.Constants;

@Repository("LoginDao")
public class LoginDaoImpl implements LoginDao {

	@Override
	public User getUserProfile(Login login) {
		List<User> usersList = Constants.getUsersList();
		User authenticatedUser = new User();
		for (User user : usersList) {
			if (user.getEmailId().equalsIgnoreCase(login.getUsername())
					&& user.getPassword().equalsIgnoreCase(login.getPassword())) {
				authenticatedUser = user;
			}
		}

		return authenticatedUser;

	}

}
