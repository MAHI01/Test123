package com.demo.att.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.demo.att.dao.CartDao;
import com.demo.att.model.Device;

@Repository("cartDao")
public class CartDaoImpl implements CartDao {

	@Override
	public List<Device> addDevice(String deviceId) {
		// TODO Auto-generated method stub
		return null;
	}

}
