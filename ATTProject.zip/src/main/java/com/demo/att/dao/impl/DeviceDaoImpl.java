package com.demo.att.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.demo.att.dao.DeviceDao;
import com.demo.att.model.Device;
import com.demo.util.Constants;

@Repository("deviceDao")
public class DeviceDaoImpl implements DeviceDao {

	@Override
	public List<Device> getDeviceList() {
		List<Device> deviceList = Constants.getDeviceList();
		return deviceList;
	}

	@Override
	public Device getDeviceDetails(String deviceId) {
		List<Device> deviceList = Constants.getDeviceList();
		Device device = new Device();
		for (Device d : deviceList) {
			if (!StringUtils.isEmpty(d.getDeviceId()) && d.getDeviceId().equalsIgnoreCase(deviceId)) {
				device = d;
				break;
			}
		}
		return device;
	}

}
