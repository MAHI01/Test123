package com.demo.att.dao;

import java.util.List;

import com.demo.att.model.Device;

public interface DeviceDao {
	public List<Device> getDeviceList();

	public Device getDeviceDetails(String deviceId);
}
