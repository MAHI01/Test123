package com.demo.att.service;

import java.util.List;

import com.demo.att.model.Device;

public interface CartService {
	public List<Device> addDevice(String deviceId);

}
