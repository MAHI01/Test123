package com.demo.att.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.att.dao.CartDao;
import com.demo.att.model.Device;
import com.demo.att.service.CartService;

@Service("cartService")
public class CartServiceImpl implements CartService {

	@Autowired
	CartDao cartDao;

	@Override
	public List<Device> addDevice(String deviceId) {
		return cartDao.addDevice(deviceId);
	}

}
