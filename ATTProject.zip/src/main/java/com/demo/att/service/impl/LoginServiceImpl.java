package com.demo.att.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.att.dao.LoginDao;
import com.demo.att.model.Login;
import com.demo.att.model.User;
import com.demo.att.service.LoginService;

@Service("LoginService")
public class LoginServiceImpl implements LoginService{

	@Autowired 
	LoginDao loginDao;
	
	@Override
	public User getUserProfile(Login login) {
		return loginDao.getUserProfile(login);
	}

}
