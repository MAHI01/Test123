package com.demo.att.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.demo.att.model.Device;
import com.demo.att.service.DeviceService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

//@Controller("deviceController")
@RestController("deviceController")
@RequestMapping("/")
public class DeviceController {

	@Autowired
	DeviceService deviceService;

	@RequestMapping(value = "/shop/wireless/devices/", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<Device> getDeviceList(HttpServletRequest request) {
		ObjectMapper mapperObj = new ObjectMapper();
		List<Device> deviceList = deviceService.getDeviceList();
		String devicesList = null;
		try {
			devicesList = mapperObj.writeValueAsString(deviceList);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return deviceList;
	}

	@RequestMapping(value = "/shop/wireless/devices/details", method = RequestMethod.GET)
	public Device getDeviceDetails(@RequestParam String deviceId) {
		Device device = deviceService.getDeviceDetails(deviceId);
		return device;
	}
}
