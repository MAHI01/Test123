package com.demo.att.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.demo.att.model.Login;
import com.demo.att.model.User;
import com.demo.att.service.LoginService;
import com.demo.util.UrlTokenizer;

@RestController("loginController")
@RequestMapping("/")
public class LoginController {

	@Autowired
	LoginService loginService;

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public User login(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute Login login) {
		User user = loginService.getUserProfile(login);
		if (!StringUtils.isEmpty(user.getEmailId())) {
			String secretToken = UrlTokenizer.generateToken(user);
			response.setHeader("Token", secretToken);			
		}
		setUserInSession(request, user);
		return user;
	}

	private void setUserInSession(HttpServletRequest request, User user) {
		request.getSession().setAttribute("user", user);
	}
}
