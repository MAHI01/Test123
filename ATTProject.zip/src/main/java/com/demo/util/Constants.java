package com.demo.util;

import java.util.ArrayList;
import java.util.List;

import com.demo.att.model.Device;
import com.demo.att.model.User;

public class Constants {

	private static final String[] colrsArr1 = { "Midnight Black", "Orchid Gray" };
	private static final String[] colrsArr2 = { "Meteor Gray", "Titanium Gold" };
	private static final String configuration = "32 to 256 GB";

	public static final String SESSION_DEVICE_ATTR = "deviceAttribute";

	public static List<User> getUsersList() {
		List<User> usersList = new ArrayList<User>();
		User user = new User();
		user.setId(123);
		user.setRole("Admin");
		user.setUserName("Admin");
		user.setEmailId("Admin@att.com");
		user.setPassword("admin");
		usersList.add(user);
		return usersList;
	}

	public static List<Device> getDeviceList() {
		List<Device> deviceList = new ArrayList<Device>();

		Device device1 = new Device();
		device1.setDeviceId("sku001");
		device1.setDesciption("Samsung Galaxy Note8");
		device1.setColors(colrsArr1);
		device1.setConfiguration(configuration);
		device1.setPrice(31.67);
		device1.setImgSource("./resources/images/galaxynote8.PNG");
		device1.setQuantity(1);

		Device device2 = new Device();
		device2.setDeviceId("sku002");
		device2.setDesciption("Samsung Galaxy S8 Active");
		device2.setColors(colrsArr2);
		device2.setConfiguration(configuration);
		device2.setPrice(28.34);
		device2.setImgSource("./resources/images/galaxys8active.PNG");
		device2.setQuantity(1);

		deviceList.add(device1);
		deviceList.add(device2);

		return deviceList;

	}

}
